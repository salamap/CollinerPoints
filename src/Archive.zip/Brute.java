//import java.util.Arrays;
//
//public class Brute {
//	
//	public static void main(String[] args) {
//		
//        Point[] inputPoints;
//        Point[] collinearPoints = new Point[4];
//        
//		// rescale coordinates and turn on animation mode
//        StdDraw.setXscale(0, 32768);
//        StdDraw.setYscale(0, 32768);
//        StdDraw.show(0);
//        
//        // read in the input
//        String filename = args[0];
//        In in = new In(filename);
//        
//        // read in total num of points
//        int N = in.readInt();
//        
//        // create the array of points
//        inputPoints = new Point[N];
//        for (int i = 0; i < N; i++) {
//            int x = in.readInt();
//            int y = in.readInt();
//            inputPoints[i] = new Point(x, y);
//            inputPoints[i].draw();
//        }
//       
//        for (int i = 0; i < N; i++) {
//        	
//        	for (int j = i + 1; j < N; j++) {
//        		
//        		if (inputPoints[i].compareTo(inputPoints[j]) == 0) continue;
//        		
//        		double firstSlope = inputPoints[i].slopeTo(inputPoints[j]);
//        		
//            	for (int k = j + 1; k < N; k++) {
//            		
//            		if (inputPoints[i].compareTo(inputPoints[k]) == 0 ||
//            			inputPoints[j].compareTo(inputPoints[k]) == 0) {
//            			continue;
//            		}
//            		
//            		double secondSlope = inputPoints[i].slopeTo(inputPoints[k]);
//            		
//                   	for (int l = k + 1; l < N; l++) {
//                   		
//                		if (inputPoints[i].compareTo(inputPoints[l]) == 0 ||
//                    		inputPoints[j].compareTo(inputPoints[l]) == 0 ||
//                    		inputPoints[k].compareTo(inputPoints[l]) == 0) {
//                    			continue;
//                    		}
//                		
//                   		double thirdSlope = inputPoints[i].slopeTo(inputPoints[l]);
//                   		
//                		if (firstSlope == secondSlope && firstSlope == thirdSlope) {
//                			
//                			collinearPoints[0] = inputPoints[i];
//                			collinearPoints[1] = inputPoints[j];
//                			collinearPoints[2] = inputPoints[k];
//                			collinearPoints[3] = inputPoints[l];
//                			
//                			Arrays.sort(collinearPoints);
//                			
//                			collinearPoints[0].drawTo(collinearPoints[3]);
//                			//StdDraw.show(10);
//                			StdOut.println(collinearPoints[0].toString() + "-> " + 
//                					       collinearPoints[1].toString() + "-> " +
//                					       collinearPoints[2].toString() + "-> " +
//                					       collinearPoints[3].toString());
//                		}
//                   	}
//                }
//            }
//        }
//        // display to screen all at once
//        StdDraw.show(0);
//	}
//
//}

public class Brute {

        public static void main(String[] args) {
                In in = new In(args[0]);      // input file
        int N = in.readInt();         // number of points N

        // repeatedly read in sites to open and draw resulting system
        Point[] points = new Point[N];
        
        int i = 0;
        while (!in.isEmpty()) {
            int x = in.readInt();
            int y = in.readInt();
            Point point = new Point(x, y);
            points[i] = point;
            i++;
        }
        
        Quick.sort(points);

        for (int a = 0; a < points.length; a++)
                for (int b = a+1; b < points.length; b++)
                        for (int c = b+1; c < points.length; c++)
                                for (int d = c+1; d < points.length; d++) {
                                        if (points[a].slopeTo(points[b]) == points[a].slopeTo(points[c]) && points[a].slopeTo(points[b]) == points[a].slopeTo(points[d])) {
                                                StdOut.println(points[a].toString() + " -> " + 
                                                                                points[b].toString() + " -> " + 
                                                                                points[c].toString() + " -> " +
                                                                                points[d].toString());
                                        
                                                StdDraw.setXscale(0, 32768);
                                                StdDraw.setYscale(0, 32768);
                                                points[a].draw();
                                                points[b].draw();
                                                points[a].draw();
                                                points[c].draw();
                                                points[a].drawTo(points[d]);
                                        }
                                }
        }

}
